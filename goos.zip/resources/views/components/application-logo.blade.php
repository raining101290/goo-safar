<a class="logo handlee-regular text-success" href="/">
    Goo Safar
</a>